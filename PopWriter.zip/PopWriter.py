# from .MapClass import *
import os
import pandas as pd
import numpy as np
from collections import Counter
from PIL import Image

# INPUT_FILES_DIR = os.getcwd() + "\\Input_Files\\mu\\"
INPUT_FILES_DIR = os.getcwd() + "\\Input_Files\\imp19c\\"
# INPUT_FILES_DIR = os.getcwd() + "\\Input_Files\\"
OUTPUT_FILES_DIR = os.getcwd() + "\\Output_Files\\"

PIXEL_CHECKER = 1

class Province():
    def __init__(self, rgb):
        self.rgb = rgb
        self.num_lower_strata, self.num_middle_strata, self.num_proletariat, self.num_slaves, \
        self.num_tribesmen, self.num_upper_strata = [], [], [], [], [], []

    def add_all_pixels(self, prov_pix, civ_pop_pix, tribe_pop_pix):
        self.add_pop_pix(civ_pop_pix, tribe_pop_pix)

    def add_pop_pix(self, strata_pop_pix, other_pop_pix):
        self.num_lower_strata.append(strata_pop_pix[0])
        self.num_middle_strata.append(strata_pop_pix[1])
        self.num_upper_strata.append(strata_pop_pix[2])
        self.num_proletariat.append(other_pop_pix[0])
        self.num_slaves.append(other_pop_pix[1])
        self.num_tribesmen.append(other_pop_pix[2])

    def get_dominant_pixels(self):
        self.dom_area = Counter(self.area).most_common(1)


class PopWriter():
    def __init__(self):
        self.initial_file_setup()
        self.load_images()  # Loading in all images used to create game files
        self.create_province_dataframe() # Create a dataframe into which to write pop numbers
        self.width = len(self.land_province_array)  # Width dimension of the map
        self.height = len(self.land_province_array[0])  # Height dimension of the map
        self.create_sets()  # Creates sets of all province arrays
        self.create_lists()  # Converts the appropriate sets to lists
        self.assign_provinces()  # Main loops that creates hierarchical relationships and province histories

        self.create_province_dataframe()

        self.write_pop_data()

        print("Job complete")

    @staticmethod
    def image_to_array(image_str):
        """
        Loads an image, hashes the RGB value, stores it in a numpy array, and returns it
        :param image_str:
        :return: bit_array
        """
        pic = Image.open(INPUT_FILES_DIR + image_str)
        array = np.array(pic, dtype="int32")
        bit_array = array[:, :, 0] * 256 * 256 + array[:, :, 1] * 256 + array[:, :, 2]
        return bit_array

    @staticmethod
    def image_to_array_no_hash(image_str):
        """
        Loads an image, hashes the RGB value, stores it in a numpy array, and returns it
        :param image_str:
        :return: bit_array
        """
        pic = Image.open(INPUT_FILES_DIR + image_str)
        array = np.array(pic, dtype="int32")
        return array

    @staticmethod
    def directory_setup(path):
        """
        Creates directories if they do not exist
        :param path:
        :return: path
        """

        try:
            os.mkdir(path)
        except OSError:
            print("Creation of the directory %s failed" % path)
            return path
        else:
            print("Successfully created the directory %s " % path)
            return path

    def initial_file_setup(self):
        """
        Creates the necessary directories and files. Will throw an error if the directories already exist but that can be ignored
        :return: map directory, localisation directory
        """
        self.out_dir = self.directory_setup(os.getcwd() + "\\Output_Files\\")
        self.map_dir = self.directory_setup(os.getcwd() + "\\Output_Files\\map_data\\")

    def load_images(self):
        self.strata_population_array = self.image_to_array_no_hash("strata_population.png")
        self.other_population_array = self.image_to_array_no_hash("other_population.png")
        self.land_province_array = self.image_to_array("land_provinces.png")

    def create_sets(self):
        self.land_provs_set = set(self.land_province_array.flatten())
        self.used_provs = self.land_provs_set.copy()

    def create_lists(self):
        self.prov_list = list(self.land_provs_set)

        self.province_population_list = [(100, 100, 100, 100, 100, 100)] * len(self.land_provs_set)
        ######################## Initializes lists of lists for storing hierarchical assignments #######################
        self.prov_obj = [None] * len(self.prov_list)

    def assign_provinces(self):
        """
        The main loop where the magic happens
        :return:
        """
        for x in range(int(self.width)):

            land_prov_array_x = self.land_province_array[x]
            strata_population_array_x = self.strata_population_array[x]
            other_population_array_x = self.other_population_array[x]

            total_iterations = self.width

            for y in range(self.height):
                prov_pixel = land_prov_array_x[y]

                strata_population_pixel = strata_population_array_x[y]
                other_population_pixel = other_population_array_x[y]

                if prov_pixel in self.used_provs:
                    self.create_prov_history(prov_pixel)
                    self.used_provs.remove(prov_pixel)
                elif x*y % PIXEL_CHECKER**2 == 0:
                    self.expand_prov_history(prov_pixel, strata_population_pixel, other_population_pixel)

            print("Completed " + str(x) + " of " + str(total_iterations) + " iterations")

        self.consolidate_prov_history()


    def expand_prov_history(self, prov_pixel, strata_population_pixel, other_population_pixel):
        idx = self.prov_list.index(prov_pixel)
        self.prov_obj[idx].add_all_pixels(prov_pixel, strata_population_pixel, other_population_pixel)

    def create_prov_history(self, prov_pixel):
        idx = self.prov_list.index(prov_pixel)
        self.prov_obj[idx] = Province(prov_pixel)

    def consolidate_prov_history(self):
        for province in self.prov_obj:
            idx = self.prov_obj.index(province)
            if province != None:
                try:
                    num_lower_strata_pix = Counter(province.num_lower_strata).most_common()[0][0]
                    num_middle_strata_pix = Counter(province.num_middle_strata).most_common()[0][0]
                    num_proletariat_pix = Counter(province.num_proletariat).most_common()[0][0]
                    num_slaves_pix = Counter(province.num_slaves).most_common()[0][0]
                    num_tribesmen_pix = Counter(province.num_tribesmen).most_common()[0][0]
                    num_upper_strata_pix = Counter(province.num_upper_strata).most_common()[0][0]
                except:
                    print(f"Problem RGB = {self.unhash_pixel(province.rgb)}")

                num_lower_strata, num_middle_strata, num_upper_strata, num_proletariat, num_slaves, num_tribesemen = \
                    self.get_population((num_lower_strata_pix, num_middle_strata_pix, num_upper_strata_pix),
                                        (num_proletariat_pix, num_slaves_pix, num_tribesmen_pix))

                self.province_population_list[idx] = (num_lower_strata, num_middle_strata, num_upper_strata, num_proletariat, num_slaves, num_tribesemen)

    def get_population(self, strata_pop_pixel, other_pop_pixel):
        num_lower_strata = (strata_pop_pixel[0]-100) #red
        num_middle_strata = (strata_pop_pixel[1]-100) #green
        num_upper_strata = (strata_pop_pixel[2]-100) #blue
        num_proletariat = (other_pop_pixel[0]-100) #red
        num_slaves = (other_pop_pixel[1]-100) #green
        num_tribesmen = (other_pop_pixel[2]-100) #blue
        return num_lower_strata, num_middle_strata, num_upper_strata, num_proletariat, num_slaves, num_tribesmen

    def hash_pixel(self, unhashed_pixel):
        return unhashed_pixel[0]*256*256 + unhashed_pixel[1]*256 + unhashed_pixel[2]

    def unhash_pixel(self, hashed_pixel):
        r = (hashed_pixel >> 16) & 0xFF
        g = (hashed_pixel >> 8) & 0xFF
        b = hashed_pixel & 0xFF
        return tuple((r, g, b))

    def create_province_dataframe(self):
        definition_file_location = INPUT_FILES_DIR + "definition.csv"
        self.province_definition = pd.read_csv(definition_file_location, sep=";", usecols=["PROVID", "R", "G", "B"])

    def write_pop_data(self):
        provinces = []
        for idx, val in enumerate(self.prov_list):
            color = self.unhash_pixel(val)
            population = self.province_population_list[idx]
            province_data = color + population
            provinces.append(province_data)

        province_df = pd.DataFrame(provinces, columns=["R", "G", "B", "lower_strata", "middle_strata",
                    "upper_strata", "proletariat", "slaves", "tribesmen"])

        merged_data = province_df.merge(self.province_definition, how="left", on=["R", "G", "B"])

        merged_data.to_csv(r"pops_by_province.csv", index=False)



def main():
    world = PopWriter()

if __name__ == "__main__":
    main()
